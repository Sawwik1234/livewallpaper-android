package app.vidwall

import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.RangeSlider
import com.google.android.material.slider.Slider
import java.util.Locale

/**
 * Редактор одного видео с живым предпросмотром.
 * Рамка предпросмотра имеет форму вашего экрана: что видно в ней, то будет и на обоях.
 * Пальцем двигаем кадр, двумя пальцами масштабируем. Ниже: фрагмент (начало и конец) и скорость.
 */
class VideoEditorActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var profile: Profile
    private lateinit var info: VideoInfo
    private lateinit var entry: VideoEntry

    private lateinit var preview: SurfaceView
    private lateinit var zoomLabel: TextView
    private lateinit var trimLabel: TextView
    private lateinit var speedLabel: TextView
    private lateinit var trimSlider: RangeSlider
    private lateinit var speedSlider: Slider

    private var renderer: GlRenderer? = null
    private var player: ExoPlayer? = null
    private var attached = false

    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var videoAspect = 0f

    private var lastX = 0f
    private var lastY = 0f
    private lateinit var scaleDetector: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        profile = Profile.of(intent.getStringExtra(EXTRA_PROFILE))
        val id = intent.getLongExtra(EXTRA_ID, -1L)
        val loadedInfo = VideoRepository.info(this, id)
        val loadedEntry = Prefs.entries(this, profile).firstOrNull { it.id == id }
        if (loadedInfo == null || loadedEntry == null) {
            finish()
            return
        }
        info = loadedInfo
        entry = loadedEntry
        zoom = entry.zoom
        panX = entry.panX
        panY = entry.panY

        preview = findViewById(R.id.preview)
        zoomLabel = findViewById(R.id.zoomLabel)
        trimLabel = findViewById(R.id.trimLabel)
        speedLabel = findViewById(R.id.speedLabel)
        trimSlider = findViewById(R.id.trimSlider)
        speedSlider = findViewById(R.id.speedSlider)
        findViewById<TextView>(R.id.videoName).text = info.name

        setupPreviewSize()
        setupGestures()
        setupSliders()

        findViewById<MaterialButton>(R.id.btnFill).setOnClickListener {
            zoom = 1f
            panX = 0f
            panY = 0f
            pushFraming()
        }
        findViewById<MaterialButton>(R.id.btnFit).setOnClickListener {
            if (videoAspect > 0f) {
                zoom = FramingMath.containZoom(videoAspect, viewAspect())
                panX = 0f
                panY = 0f
                pushFraming()
            }
        }
        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener { save() }
        findViewById<MaterialButton>(R.id.btnReset).setOnClickListener { reset() }

        renderer = GlRenderer { surface -> onVideoSurface(surface) }
        preview.holder.addCallback(this)
        player = createPlayer()
        loadClip()
        pushFraming()
    }

    // ---------- предпросмотр ----------

    /** Рамка предпросмотра повторяет пропорции экрана телефона. */
    private fun setupPreviewSize() {
        val dm = resources.displayMetrics
        val aspect = dm.widthPixels.toFloat() / dm.heightPixels
        val h = (dm.heightPixels * 0.5f).toInt()
        val w = (h * aspect).toInt()
        val frame = findViewById<FrameLayout>(R.id.previewFrame)
        frame.layoutParams = frame.layoutParams.apply { height = h }
        preview.layoutParams = FrameLayout.LayoutParams(w, h).apply { gravity = Gravity.CENTER_HORIZONTAL }
    }

    private fun viewAspect(): Float {
        val w = preview.layoutParams.width
        val h = preview.layoutParams.height
        return if (h > 0) w.toFloat() / h else 1f
    }

    private fun createPlayer(): ExoPlayer {
        val p = ExoPlayer.Builder(this).build()
        p.volume = 0f
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                videoAspect = if (videoSize.height > 0) {
                    videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                } else 0f
                renderer?.setVideoSize(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
                zoom = zoom.coerceIn(minZoom(), MAX_ZOOM)
                pushFraming()
            }
        })
        return p
    }

    private fun minZoom(): Float =
        if (videoAspect > 0f) minOf(1f, FramingMath.containZoom(videoAspect, viewAspect())) else 1f

    /** Собирает ролик с выбранным фрагментом и запускает по кругу. */
    private fun loadClip() {
        val p = player ?: return
        val (s, e) = currentRange()
        val b = MediaItem.Builder().setUri(VideoRepository.uriOf(info.id))
        if (s > 0 || e > 0) {
            val c = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s)
            if (e > s) c.setEndPositionMs(e)
            b.setClippingConfiguration(c.build())
        }
        p.setMediaItem(b.build())
        p.setPlaybackSpeed(speedSlider.value)
        p.prepare()
        p.playWhenReady = true
    }

    private fun onVideoSurface(surface: Surface?) {
        val p = player ?: return
        if (surface != null && surface.isValid) p.setVideoSurface(surface) else p.clearVideoSurface()
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        val r = renderer ?: return
        if (!attached) {
            attached = true
            r.attach(holder.surface, width, height)
        } else {
            r.resize(width, height)
        }
        pushFraming()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        player?.clearVideoSurface()
        renderer?.detach()
        attached = false
    }

    // ---------- жесты ----------

    private fun setupGestures() {
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(minZoom(), MAX_ZOOM)
                pushFraming()
                return true
            }
        })
        preview.setOnTouchListener { v, ev ->
            v.parent?.requestDisallowInterceptTouchEvent(true)
            handleTouch(ev)
            true
        }
    }

    private fun handleTouch(ev: MotionEvent) {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = ev.x
                lastY = ev.y
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                lastX = ev.getX(0)
                lastY = ev.getY(0)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val remaining = if (ev.actionIndex == 0) 1 else 0
                lastX = ev.getX(remaining)
                lastY = ev.getY(remaining)
            }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount == 1 && !scaleDetector.isInProgress) {
                    pan(ev.x - lastX, ev.y - lastY)
                    lastX = ev.x
                    lastY = ev.y
                }
            }
        }
    }

    /** Сдвиг пальцем: пиксели переводим в долю доступного запаса кадра. */
    private fun pan(dx: Float, dy: Float) {
        if (videoAspect <= 0f) return
        val w = preview.layoutParams.width.toFloat()
        val h = preview.layoutParams.height.toFloat()
        val (bx, by) = FramingMath.coverScale(videoAspect, viewAspect())
        val maxX = FramingMath.maxShift(bx, zoom)
        val maxY = FramingMath.maxShift(by, zoom)
        if (maxX > 1e-3f) panX = (panX + (2f * dx / w) / maxX).coerceIn(-1f, 1f)
        if (maxY > 1e-3f) panY = (panY - (2f * dy / h) / maxY).coerceIn(-1f, 1f)
        pushFraming()
    }

    private fun pushFraming() {
        renderer?.setFraming(zoom, panX, panY)
        zoomLabel.text = getString(R.string.zoom_label, String.format(Locale.ROOT, "%.2f", zoom))
    }

    // ---------- фрагмент и скорость ----------

    private fun setupSliders() {
        val durationSec = info.durationMs / 1000f
        if (durationSec >= 0.5f) {
            val endSec = if (entry.endMs > 0) minOf(entry.endMs / 1000f, durationSec) else durationSec
            val startSec = (entry.startMs / 1000f).coerceIn(0f, endSec)
            trimSlider.valueFrom = 0f
            trimSlider.valueTo = durationSec
            trimSlider.setValues(startSec, endSec)
            trimSlider.addOnChangeListener { _, _, _ -> updateTrimLabel() }
            trimSlider.addOnSliderTouchListener(object : RangeSlider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: RangeSlider) {}
                override fun onStopTrackingTouch(slider: RangeSlider) {
                    loadClip()
                }
            })
        } else {
            trimSlider.isEnabled = false
        }
        updateTrimLabel()

        speedSlider.value = snapSpeed(entry.speed)
        speedSlider.setLabelFormatter { String.format(Locale.ROOT, "%.2f×", it) }
        speedSlider.addOnChangeListener { _, value, _ ->
            player?.setPlaybackSpeed(value)
            updateSpeedLabel()
        }
        updateSpeedLabel()
    }

    private fun snapSpeed(s: Float): Float = (Math.round(s * 4f) / 4f).coerceIn(0.25f, 2.0f)

    private fun currentRange(): Pair<Long, Long> {
        if (!trimSlider.isEnabled) return Pair(0L, 0L)
        val v = trimSlider.values
        return Pair((v[0] * 1000).toLong(), (v[1] * 1000).toLong())
    }

    private fun updateTrimLabel() {
        val (s, e) = currentRange()
        val end = if (e > 0) e else info.durationMs
        trimLabel.text = getString(R.string.trim_label, formatTime(s), formatTime(end))
    }

    private fun updateSpeedLabel() {
        speedLabel.text = getString(R.string.speed_label, String.format(Locale.ROOT, "%.2f", speedSlider.value))
    }

    private fun reset() {
        if (trimSlider.isEnabled) trimSlider.setValues(0f, info.durationMs / 1000f)
        speedSlider.value = 1.0f
        zoom = 1f
        panX = 0f
        panY = 0f
        updateTrimLabel()
        updateSpeedLabel()
        loadClip()
        pushFraming()
    }

    private fun save() {
        var (start, end) = currentRange()
        if (start < 50) start = 0L
        if (end >= info.durationMs - 50) end = 0L
        if (end > 0 && end - start < 300) {
            Toast.makeText(this, R.string.too_short, Toast.LENGTH_SHORT).show()
            return
        }
        val updated = entry.copy(
            startMs = start,
            endMs = end,
            speed = speedSlider.value,
            zoom = zoom,
            panX = panX,
            panY = panY
        )
        Prefs.setEntries(
            this, profile,
            Prefs.entries(this, profile).map { if (it.id == entry.id) updated else it }
        )
        finish()
    }

    // ---------- жизненный цикл ----------

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        player?.let {
            it.clearVideoSurface()
            it.release()
        }
        player = null
        renderer?.detach()
        renderer?.release()
        renderer = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ID = "video_id"
        const val EXTRA_PROFILE = "profile"
        private const val MAX_ZOOM = 4f
    }
}
