package app.vidwall

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.google.android.material.materialswitch.MaterialSwitch

/** Общие помощники для карточек настроек. */
object Cards {
    fun bind(card: View, icon: Int, title: String, subtitle: String?) {
        card.findViewById<ImageView>(R.id.cardIcon).setImageResource(icon)
        card.findViewById<TextView>(R.id.cardTitle).text = title
        val sub = card.findViewById<TextView>(R.id.cardSubtitle)
        if (subtitle.isNullOrEmpty()) {
            sub.visibility = View.GONE
        } else {
            sub.visibility = View.VISIBLE
            sub.text = subtitle
        }
    }

    /** Показывает переключатель в карточке; нажатие на всю карточку переключает его. */
    fun switchOf(card: View): MaterialSwitch {
        val sw = card.findViewById<MaterialSwitch>(R.id.cardSwitch)
        sw.visibility = View.VISIBLE
        card.setOnClickListener { sw.toggle() }
        return sw
    }
}
