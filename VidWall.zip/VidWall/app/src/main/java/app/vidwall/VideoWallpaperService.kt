package app.vidwall

import android.content.SharedPreferences
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * Видеообои: ExoPlayer рисует прямо на поверхность обоев.
 * Плеер на паузе, пока обои не видны, и освобождается через 30 секунд невидимости.
 * Все ошибки воспроизведения перехватываются: сбойное видео пропускается.
 */
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    private inner class VideoEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var player: ExoPlayer? = null
        private var currentHolder: SurfaceHolder? = null
        private var isVisibleNow = false
        private var errorStreak = 0

        private val releaseRunnable = Runnable { releasePlayer() }
        private val reloadRunnable = Runnable { if (isVisibleNow) refreshPlaylist() }

        private val mediaObserver = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) = scheduleReload()
        }
        private val prefsListener =
            SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> scheduleReload() }

        private fun scheduleReload() {
            handler.removeCallbacks(reloadRunnable)
            handler.postDelayed(reloadRunnable, RELOAD_DELAY_MS)
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            try {
                contentResolver.registerContentObserver(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver
                )
            } catch (e: Exception) {
                Log.w(TAG, "registerContentObserver failed", e)
            }
            Prefs.get(applicationContext).registerOnSharedPreferenceChangeListener(prefsListener)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            currentHolder = holder
            if (isVisibleNow) startPlayback()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            currentHolder = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            isVisibleNow = visible
            handler.removeCallbacks(releaseRunnable)
            if (visible) {
                startPlayback()
            } else {
                player?.pause()
                handler.postDelayed(releaseRunnable, RELEASE_DELAY_MS)
            }
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            try {
                contentResolver.unregisterContentObserver(mediaObserver)
            } catch (e: Exception) {
                Log.w(TAG, "unregisterContentObserver failed", e)
            }
            Prefs.get(applicationContext).unregisterOnSharedPreferenceChangeListener(prefsListener)
            releasePlayer()
            super.onDestroy()
        }

        private fun startPlayback() {
            val holder = currentHolder ?: return
            try {
                errorStreak = 0
                val p = player ?: createPlayer().also { player = it }
                p.setVideoSurfaceHolder(holder)
                refreshPlaylist()
                if (p.mediaItemCount > 0 && p.playbackState == Player.STATE_IDLE) p.prepare()
                p.playWhenReady = true
            } catch (e: Exception) {
                Log.e(TAG, "startPlayback failed", e)
                releasePlayer()
            }
        }

        private fun createPlayer(): ExoPlayer {
            val p = ExoPlayer.Builder(applicationContext).build()
            p.volume = 0f
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                .build()
            p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            p.addListener(object : Player.Listener {
                override fun onRenderedFirstFrame() {
                    errorStreak = 0
                }

                override fun onPlayerError(error: PlaybackException) {
                    handleError(p, error)
                }
            })
            return p
        }

        private fun handleError(p: ExoPlayer, error: PlaybackException) {
            Log.w(TAG, "Playback error", error)
            errorStreak++
            if (errorStreak > p.mediaItemCount.coerceAtLeast(1) + 1) {
                Log.e(TAG, "Too many consecutive errors, giving up until next show")
                return
            }
            try {
                if (p.mediaItemCount > 1) p.seekToNextMediaItem()
                p.prepare()
            } catch (e: Exception) {
                Log.e(TAG, "Recovery failed", e)
            }
        }

        /** Пересобирает плейлист из галереи, только если набор видео изменился. */
        private fun refreshPlaylist() {
            val p = player ?: return
            val uris = VideoRepository.queryVideos(applicationContext, Prefs.buckets(applicationContext))
            p.shuffleModeEnabled = Prefs.shuffle(applicationContext)
            if (uris.isEmpty()) {
                p.stop()
                p.clearMediaItems()
                return
            }
            p.repeatMode = if (uris.size == 1) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_ALL

            val currentUris = (0 until p.mediaItemCount).map {
                p.getMediaItemAt(it).localConfiguration?.uri
            }
            if (currentUris == uris) return

            val playingUri = p.currentMediaItem?.localConfiguration?.uri
            val index = uris.indexOf(playingUri)
            val items = uris.map { MediaItem.fromUri(it) }
            if (index >= 0) {
                p.setMediaItems(items, index, p.currentPosition)
            } else {
                p.setMediaItems(items)
            }
            p.prepare()
        }

        private fun releasePlayer() {
            val p = player ?: return
            player = null
            try {
                p.clearVideoSurface()
                p.release()
            } catch (e: Exception) {
                Log.w(TAG, "release failed", e)
            }
        }
    }

    private companion object {
        const val TAG = "VidWall"
        const val RELOAD_DELAY_MS = 1500L
        const val RELEASE_DELAY_MS = 30_000L
    }
}
