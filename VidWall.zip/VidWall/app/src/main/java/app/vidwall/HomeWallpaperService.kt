package app.vidwall

/** Обои для рабочего стола (или для обоих экранов, если выбрать «оба» при установке). */
class HomeWallpaperService : BaseVideoWallpaperService(Profile.HOME)
