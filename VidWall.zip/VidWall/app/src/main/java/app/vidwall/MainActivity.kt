package app.vidwall

import android.Manifest
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var btnGrant: MaterialButton
    private lateinit var btnAlbums: MaterialButton
    private lateinit var switchShuffle: MaterialSwitch

    private val permission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        btnGrant = findViewById(R.id.btnGrant)
        btnAlbums = findViewById(R.id.btnAlbums)
        switchShuffle = findViewById(R.id.switchShuffle)

        btnGrant.setOnClickListener { permissionLauncher.launch(permission) }
        btnAlbums.setOnClickListener { loadAlbums() }
        switchShuffle.isChecked = Prefs.shuffle(this)
        switchShuffle.setOnCheckedChangeListener { _, checked -> Prefs.setShuffle(this, checked) }
        findViewById<MaterialButton>(R.id.btnSet).setOnClickListener { setWallpaper() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        if (!hasPermission()) {
            status.setText(R.string.status_no_permission)
            btnGrant.isEnabled = true
            btnAlbums.isEnabled = false
            return
        }
        btnGrant.isEnabled = false
        btnAlbums.isEnabled = true
        val app = applicationContext
        thread {
            val count = VideoRepository.queryVideos(app, Prefs.buckets(app)).size
            runOnUiThread { status.text = getString(R.string.status_found, count) }
        }
    }

    private fun loadAlbums() {
        val app = applicationContext
        thread {
            val albums = VideoRepository.albums(app)
            runOnUiThread { showAlbumDialog(albums) }
        }
    }

    private fun showAlbumDialog(albums: List<Album>) {
        if (isFinishing || isDestroyed) return
        if (albums.isEmpty()) {
            Toast.makeText(this, R.string.no_albums, Toast.LENGTH_SHORT).show()
            return
        }
        val selected = Prefs.buckets(this)
        val checked = BooleanArray(albums.size) { selected.isEmpty() || albums[it].id in selected }
        val labels = albums.map { "${it.name} (${it.count})" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.choose_albums)
            .setMultiChoiceItems(labels, checked) { _, index, isChecked -> checked[index] = isChecked }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val chosen = albums.filterIndexed { i, _ -> checked[i] }.map { it.id }.toSet()
                // Все альбомы или ни одного = «все видео»: новые альбомы подхватятся сами.
                val toSave = if (chosen.size == albums.size) emptySet() else chosen
                Prefs.setBuckets(this, toSave)
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun setWallpaper() {
        val component = ComponentName(this, VideoWallpaperService::class.java)
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(this, "Не удалось открыть выбор обоев", Toast.LENGTH_LONG).show()
            }
        }
    }
}
