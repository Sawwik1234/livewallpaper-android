package app.vidwall

import android.Manifest
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val permission =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshAll() }

    private lateinit var pageHome: View
    private lateinit var pageVideos: View
    private lateinit var pageSettings: View

    private lateinit var cardStatus: View
    private lateinit var cardPerm: View
    private lateinit var cardSetLock: View
    private lateinit var cardBattery: View
    private lateinit var cardTransition: View
    private lateinit var listEmpty: TextView
    private lateinit var profileToggle: MaterialButtonToggleGroup
    private lateinit var lockSameSwitch: MaterialSwitch

    /** Для какого экрана сейчас редактируется набор видео. */
    private var editingProfile = Profile.HOME

    private val entryAdapter = EntryAdapter()

    /** Перетаскивание порядка видео: тянем за значок слева. */
    private val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
    ) {
        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean {
            val from = viewHolder.bindingAdapterPosition
            val to = target.bindingAdapterPosition
            if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
            entryAdapter.move(from, to)
            return true
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}

        override fun isLongPressDragEnabled(): Boolean = false

        override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
            super.clearView(recyclerView, viewHolder)
            entryAdapter.persistOrder()
        }
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pageHome = findViewById(R.id.pageHome)
        pageVideos = findViewById(R.id.pageVideos)
        pageSettings = findViewById(R.id.pageSettings)

        setupHome()
        setupVideos()
        setupSettings()

        val nav = findViewById<BottomNavigationView>(R.id.nav)
        nav.setOnItemSelectedListener {
            showPage(it.itemId)
            true
        }
        showPage(R.id.nav_home)
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    // ---------- общие помощники ----------

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun setupCard(card: View, icon: Int, title: String, subtitle: String?) {
        card.findViewById<ImageView>(R.id.cardIcon).setImageResource(icon)
        card.findViewById<TextView>(R.id.cardTitle).text = title
        val sub = card.findViewById<TextView>(R.id.cardSubtitle)
        if (subtitle.isNullOrEmpty()) {
            sub.visibility = View.GONE
        } else {
            sub.visibility = View.VISIBLE
            sub.text = subtitle
        }
    }

    private fun switchOf(card: View): MaterialSwitch {
        val sw = card.findViewById<MaterialSwitch>(R.id.cardSwitch)
        sw.visibility = View.VISIBLE
        card.setOnClickListener { sw.toggle() }
        return sw
    }

    private fun showPage(id: Int) {
        pageHome.visibility = if (id == R.id.nav_home) View.VISIBLE else View.GONE
        pageVideos.visibility = if (id == R.id.nav_videos) View.VISIBLE else View.GONE
        pageSettings.visibility = if (id == R.id.nav_settings) View.VISIBLE else View.GONE
        refreshAll()
    }

    private fun refreshAll() {
        refreshHome()
        refreshVideos()
        refreshSettings()
    }

    // ---------- Главная ----------

    private fun setupHome() {
        cardStatus = pageHome.findViewById(R.id.cardStatus)
        cardStatus.isClickable = false
        cardPerm = pageHome.findViewById(R.id.cardPerm)
        setupCard(cardPerm, R.drawable.ic_lock, getString(R.string.perm_title), getString(R.string.perm_sub))
        cardPerm.setOnClickListener { permissionLauncher.launch(permission) }

        val cardSet = pageHome.findViewById<View>(R.id.cardSet)
        setupCard(cardSet, R.drawable.ic_play, getString(R.string.set_title), getString(R.string.set_sub))
        cardSet.setOnClickListener { setWallpaper(HomeWallpaperService::class.java) }

        cardSetLock = pageHome.findViewById(R.id.cardSetLock)
        setupCard(cardSetLock, R.drawable.ic_lock, getString(R.string.set_lock_title), getString(R.string.set_lock_sub))
        cardSetLock.setOnClickListener { setWallpaper(LockWallpaperService::class.java) }
    }

    private fun setStatus(text: String, subtitle: String? = null) {
        setupCard(cardStatus, R.drawable.ic_video, text, subtitle)
    }

    private fun refreshHome() {
        // Отдельные обои для блокировки нужны, только если там другие видео.
        cardSetLock.visibility = if (Prefs.lockSameAsHome(this)) View.GONE else View.VISIBLE

        if (!hasPermission()) {
            cardPerm.visibility = View.VISIBLE
            setStatus(getString(R.string.status_no_access))
            return
        }
        cardPerm.visibility = View.GONE
        val app = applicationContext
        thread {
            val total = VideoRepository.queryAll(app).size
            val homeSel = Prefs.entries(app, Profile.HOME).size
            val lockSel = Prefs.entries(app, Profile.LOCK).size
            val lockSame = Prefs.lockSameAsHome(app)
            runOnUiThread {
                val homeLine =
                    if (homeSel > 0) getString(R.string.status_home_selected, homeSel)
                    else getString(R.string.status_home_all, total)
                val lockLine = when {
                    lockSame -> getString(R.string.status_lock_same)
                    lockSel > 0 -> getString(R.string.status_lock_own, lockSel)
                    else -> getString(R.string.status_lock_empty)
                }
                setStatus(homeLine, lockLine)
            }
        }
    }

    private fun setWallpaper(service: Class<*>) {
        val component = ComponentName(this, service)
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(this, "Не удалось открыть выбор обоев", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- Видео ----------

    private fun setupVideos() {
        val cardLockSame = pageVideos.findViewById<View>(R.id.cardLockSame)
        setupCard(cardLockSame, R.drawable.ic_lock, getString(R.string.lock_same_title), getString(R.string.lock_same_sub))
        lockSameSwitch = switchOf(cardLockSame)
        lockSameSwitch.isChecked = Prefs.lockSameAsHome(this)
        lockSameSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setLockSameAsHome(this, checked)
            // Выключили «те же видео»: сразу открываем список экрана блокировки, чтобы выбрать для него.
            editingProfile = if (checked) Profile.HOME else Profile.LOCK
            refreshAll()
        }

        profileToggle = pageVideos.findViewById(R.id.profileToggle)
        profileToggle.check(R.id.btnProfileHome)
        profileToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                editingProfile = if (checkedId == R.id.btnProfileLock) Profile.LOCK else Profile.HOME
                refreshVideos()
            }
        }

        val cardShuffle = pageVideos.findViewById<View>(R.id.cardShuffle)
        setupCard(cardShuffle, R.drawable.ic_shuffle, getString(R.string.shuffle_title), getString(R.string.shuffle_sub))
        val shuffleSwitch = switchOf(cardShuffle)
        shuffleSwitch.isChecked = Prefs.shuffle(this)
        shuffleSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setShuffle(this, checked) }

        val cardAdd = pageVideos.findViewById<View>(R.id.cardAdd)
        setupCard(cardAdd, R.drawable.ic_add, getString(R.string.add_title), getString(R.string.add_sub))
        cardAdd.setOnClickListener {
            if (hasPermission()) {
                startActivity(
                    Intent(this, VideoPickerActivity::class.java)
                        .putExtra(VideoPickerActivity.EXTRA_PROFILE, editingProfile.key)
                )
            } else {
                permissionLauncher.launch(permission)
            }
        }

        listEmpty = pageVideos.findViewById(R.id.listEmpty)
        val list = pageVideos.findViewById<RecyclerView>(R.id.entryList)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = entryAdapter
        touchHelper.attachToRecyclerView(list)
    }

    private fun refreshVideos() {
        val lockSame = Prefs.lockSameAsHome(this)
        if (lockSameSwitch.isChecked != lockSame) lockSameSwitch.isChecked = lockSame
        profileToggle.visibility = if (lockSame) View.GONE else View.VISIBLE
        if (lockSame) editingProfile = Profile.HOME
        val wantedButton = if (editingProfile == Profile.LOCK) R.id.btnProfileLock else R.id.btnProfileHome
        if (profileToggle.checkedButtonId != wantedButton) profileToggle.check(wantedButton)

        val app = applicationContext
        val profile = editingProfile
        thread {
            val rows = Prefs.entries(app, profile).map { Row(it, VideoRepository.info(app, it.id)) }
            runOnUiThread {
                if (profile != editingProfile) return@runOnUiThread
                entryAdapter.rows = rows
                entryAdapter.notifyDataSetChanged()
                listEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private data class Row(val entry: VideoEntry, val info: VideoInfo?)

    private class EntryHolder(view: View) : RecyclerView.ViewHolder(view) {
        val drag: ImageView = view.findViewById(R.id.dragHandle)
        val thumb: ImageView = view.findViewById(R.id.thumb)
        val name: TextView = view.findViewById(R.id.entryName)
        val infoText: TextView = view.findViewById(R.id.entryInfo)
        val edit: ImageButton = view.findViewById(R.id.btnEdit)
        val delete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    private inner class EntryAdapter : RecyclerView.Adapter<EntryHolder>() {
        var rows: List<Row> = emptyList()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = EntryHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_video_entry, parent, false)
        )

        override fun getItemCount() = rows.size

        fun move(from: Int, to: Int) {
            val list = rows.toMutableList()
            list.add(to, list.removeAt(from))
            rows = list
            notifyItemMoved(from, to)
        }

        /** Сохраняет порядок после того, как палец отпущен. */
        fun persistOrder() {
            Prefs.setEntries(this@MainActivity, editingProfile, rows.map { it.entry })
        }

        override fun onBindViewHolder(holder: EntryHolder, position: Int) {
            val row = rows[position]
            val e = row.entry
            val info = row.info
            if (info == null) {
                holder.name.text = "#${e.id}"
                holder.infoText.setText(R.string.entry_deleted)
                holder.thumb.setImageDrawable(null)
                holder.edit.visibility = View.GONE
            } else {
                holder.edit.visibility = View.VISIBLE
                holder.name.text = info.name
                holder.infoText.text = describe(e, info)
                Thumbs.load(this@MainActivity, e.id, 160, 160, holder.thumb)
            }
            holder.drag.setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) touchHelper.startDrag(holder)
                false
            }
            holder.edit.setOnClickListener {
                startActivity(
                    Intent(this@MainActivity, VideoEditorActivity::class.java)
                        .putExtra(VideoEditorActivity.EXTRA_ID, e.id)
                        .putExtra(VideoEditorActivity.EXTRA_PROFILE, editingProfile.key)
                )
            }
            holder.delete.setOnClickListener {
                Prefs.setEntries(
                    this@MainActivity, editingProfile,
                    Prefs.entries(this@MainActivity, editingProfile).filter { it.id != e.id }
                )
                refreshAll()
            }
        }

        private fun describe(e: VideoEntry, info: VideoInfo): String {
            val parts = ArrayList<String>()
            if (e.startMs > 0 || e.endMs > 0) {
                val end = if (e.endMs > 0) e.endMs else info.durationMs
                parts.add("${formatTime(e.startMs)}–${formatTime(end)}")
            } else {
                parts.add(getString(R.string.entry_whole) + " " + formatTime(info.durationMs))
            }
            if (e.speed != 1f) parts.add("${e.speed}×")
            if (e.isFramed) parts.add(getString(R.string.entry_framed))
            return parts.joinToString(" · ")
        }
    }

    // ---------- Настройки ----------

    private fun setupSettings() {
        cardBattery = pageSettings.findViewById(R.id.cardBattery)
        cardBattery.setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            try {
                if (pm.isIgnoringBatteryOptimizations(packageName)) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } else {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось открыть настройки батареи", Toast.LENGTH_LONG).show()
            }
        }

        val cardPower = pageSettings.findViewById<View>(R.id.cardPowerSave)
        setupCard(cardPower, R.drawable.ic_pause, getString(R.string.powersave_title), getString(R.string.powersave_sub))
        val powerSwitch = switchOf(cardPower)
        powerSwitch.isChecked = Prefs.pauseOnPowerSave(this)
        powerSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setPauseOnPowerSave(this, checked) }

        cardTransition = pageSettings.findViewById(R.id.cardTransition)
        cardTransition.setOnClickListener { startActivity(Intent(this, TransitionActivity::class.java)) }

        setupParallax()
    }

    private fun setupParallax() {
        val title = pageSettings.findViewById<TextView>(R.id.parallaxTitle)
        val slider = pageSettings.findViewById<Slider>(R.id.parallaxSlider)
        val value = (Math.round(Prefs.parallax(this) / 10f) * 10).coerceIn(0, 100)
        slider.value = value.toFloat()
        title.text = getString(R.string.parallax_title, value)
        slider.addOnChangeListener { _, v, fromUser ->
            title.text = getString(R.string.parallax_title, v.toInt())
            if (fromUser) Prefs.setParallax(this, v.toInt())
        }
    }

    private fun refreshSettings() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val ok = pm.isIgnoringBatteryOptimizations(packageName)
        setupCard(
            cardBattery,
            R.drawable.ic_bolt,
            getString(if (ok) R.string.battery_ok else R.string.battery_need),
            getString(R.string.battery_sub)
        )
        setupCard(
            cardTransition,
            R.drawable.ic_video,
            getString(R.string.tr_screen_title) + ": " + getString(Transition.info(Prefs.transition(this)).nameRes),
            getString(R.string.tr_card_sub)
        )
    }
}
