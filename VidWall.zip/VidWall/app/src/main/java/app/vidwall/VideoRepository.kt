package app.vidwall

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log

data class Album(val id: String, val name: String, val count: Int)

/** Чтение видео из галереи через MediaStore. Любые ошибки доступа дают пустой список, а не вылет. */
object VideoRepository {
    private const val TAG = "VidWall"
    private val collection: Uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    fun queryVideos(context: Context, buckets: Set<String>): List<Uri> {
        val result = ArrayList<Uri>()
        try {
            val projection = arrayOf(MediaStore.Video.Media._ID)
            var selection = "${MediaStore.Video.Media.DURATION} > 0"
            var args: Array<String>? = null
            if (buckets.isNotEmpty()) {
                val marks = buckets.joinToString(",") { "?" }
                selection += " AND ${MediaStore.Video.Media.BUCKET_ID} IN ($marks)"
                args = buckets.toTypedArray()
            }
            val order = "${MediaStore.Video.Media.DATE_ADDED} DESC"
            context.contentResolver.query(collection, projection, selection, args, order)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                while (c.moveToNext()) {
                    result.add(ContentUris.withAppendedId(collection, c.getLong(idCol)))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "queryVideos failed", e)
        }
        return result
    }

    fun albums(context: Context): List<Album> {
        val names = LinkedHashMap<String, String>()
        val counts = HashMap<String, Int>()
        try {
            val projection = arrayOf(
                MediaStore.Video.Media.BUCKET_ID,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME
            )
            val selection = "${MediaStore.Video.Media.DURATION} > 0"
            context.contentResolver.query(collection, projection, selection, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getString(idCol) ?: continue
                    if (!names.containsKey(id)) names[id] = c.getString(nameCol) ?: id
                    counts[id] = (counts[id] ?: 0) + 1
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "albums failed", e)
        }
        return names.map { Album(it.key, it.value, counts[it.key] ?: 0) }
            .sortedBy { it.name.lowercase() }
    }
}
