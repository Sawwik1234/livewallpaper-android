package app.vidwall

/** Отдельные обои для экрана блокировки: свой набор видео, когда выключено «те же видео». */
class LockWallpaperService : BaseVideoWallpaperService(Profile.LOCK)
