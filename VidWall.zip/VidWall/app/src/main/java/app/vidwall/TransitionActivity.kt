package app.vidwall

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.slider.Slider
import kotlin.concurrent.thread

/**
 * Настройка перехода с живым предпросмотром: выбираете эффект, и он сразу проигрывается на видео
 * в рамке формы вашего экрана. Все изменения сохраняются сразу.
 */
class TransitionActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var preview: SurfaceView
    private lateinit var previewHint: TextView
    private lateinit var dirBlock: View
    private lateinit var durationTitle: TextView

    private var renderer: GlRenderer? = null
    private var player: ExoPlayer? = null
    private var attached = false

    private val handler = Handler(Looper.getMainLooper())
    private val playRunnable = Runnable { play() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transition)

        preview = findViewById(R.id.preview)
        previewHint = findViewById(R.id.previewHint)
        dirBlock = findViewById(R.id.dirBlock)
        durationTitle = findViewById(R.id.durationTitle)

        setupPreviewSize()
        setupEffects()
        setupDirection()
        setupEasing()
        setupDuration()
        setupTriggers()
        findViewById<MaterialButton>(R.id.btnPlay).setOnClickListener { play() }

        renderer = GlRenderer { surface -> onVideoSurface(surface) }
        preview.holder.addCallback(this)
        player = createPlayer()
        loadPreviewVideo()
    }

    // ---------- предпросмотр ----------

    private fun setupPreviewSize() {
        val dm = resources.displayMetrics
        val aspect = dm.widthPixels.toFloat() / dm.heightPixels
        val h = (dm.heightPixels * 0.45f).toInt()
        val w = (h * aspect).toInt()
        val frame = findViewById<FrameLayout>(R.id.previewFrame)
        frame.layoutParams = frame.layoutParams.apply { height = h }
        preview.layoutParams = FrameLayout.LayoutParams(w, h).apply { gravity = Gravity.CENTER_HORIZONTAL }
    }

    private fun createPlayer(): ExoPlayer {
        val p = ExoPlayer.Builder(this).build()
        p.volume = 0f
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                renderer?.setVideoSize(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
            }

            override fun onRenderedFirstFrame() {
                // Первый показ эффекта, как только появилась картинка.
                handler.postDelayed(playRunnable, 250)
            }
        })
        return p
    }

    private fun hasPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    /** Для предпросмотра берём первое выбранное видео или самое свежее из галереи. */
    private fun loadPreviewVideo() {
        if (!hasPermission()) {
            previewHint.visibility = View.VISIBLE
            return
        }
        val app = applicationContext
        thread {
            val chosen = Prefs.entries(app, Profile.HOME).firstOrNull()?.id
                ?: VideoRepository.queryAll(app).firstOrNull()?.id
            runOnUiThread {
                val p = player
                if (chosen == null || p == null || isDestroyed) {
                    previewHint.visibility = View.VISIBLE
                } else {
                    p.setMediaItem(MediaItem.fromUri(VideoRepository.uriOf(chosen)))
                    p.prepare()
                    p.playWhenReady = true
                }
            }
        }
    }

    private fun onVideoSurface(surface: Surface?) {
        val p = player ?: return
        if (surface != null && surface.isValid) p.setVideoSurface(surface) else p.clearVideoSurface()
    }

    private fun play() {
        renderer?.startIntro(Prefs.transitionConfig(this))
    }

    /** Повторяет эффект через короткую паузу после изменения настройки. */
    private fun playSoon() {
        handler.removeCallbacks(playRunnable)
        handler.postDelayed(playRunnable, 200)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        val r = renderer ?: return
        if (!attached) {
            attached = true
            r.attach(holder.surface, width, height)
        } else {
            r.resize(width, height)
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        player?.clearVideoSurface()
        renderer?.detach()
        attached = false
    }

    // ---------- настройки ----------

    /** Заполняет группу чипов; выбранный чип отмечен, нажатие сообщает его номер. */
    private fun fillChips(group: ChipGroup, names: List<Int>, ids: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
        val inflater = LayoutInflater.from(this)
        group.removeAllViews()
        names.forEachIndexed { index, nameRes ->
            val chip = inflater.inflate(R.layout.item_chip, group, false) as Chip
            chip.id = View.generateViewId()
            chip.setText(nameRes)
            group.addView(chip)
            chip.isChecked = ids[index] == selected
            chip.setOnClickListener { onSelect(ids[index]) }
        }
    }

    private fun setupEffects() {
        val group = findViewById<ChipGroup>(R.id.effectGroup)
        val all = Transition.all
        fillChips(group, all.map { it.nameRes }, all.map { it.id }, Prefs.transition(this)) { id ->
            Prefs.setTransition(this, id)
            dirBlock.visibility = if (Transition.info(id).usesDirection) View.VISIBLE else View.GONE
            playSoon()
        }
        dirBlock.visibility = if (Transition.info(Prefs.transition(this)).usesDirection) View.VISIBLE else View.GONE
    }

    private fun setupDirection() {
        val group = findViewById<ChipGroup>(R.id.dirGroup)
        fillChips(group, Dir.labels, listOf(Dir.CENTER, Dir.LEFT, Dir.RIGHT, Dir.TOP, Dir.BOTTOM), Prefs.transitionDir(this)) {
            Prefs.setTransitionDir(this, it)
            playSoon()
        }
    }

    private fun setupEasing() {
        val group = findViewById<ChipGroup>(R.id.easeGroup)
        fillChips(
            group, Easing.labels,
            listOf(Easing.SMOOTH, Easing.FAST_START, Easing.SLOW_START, Easing.LINEAR),
            Prefs.transitionEasing(this)
        ) {
            Prefs.setTransitionEasing(this, it)
            playSoon()
        }
    }

    private fun setupDuration() {
        val slider = findViewById<Slider>(R.id.durationSlider)
        val ms = (Math.round(Prefs.transitionMs(this) / 100f) * 100).coerceIn(200, 2000)
        slider.value = ms.toFloat()
        durationTitle.text = getString(R.string.transition_dur, ms)
        slider.addOnChangeListener { _, value, fromUser ->
            durationTitle.text = getString(R.string.transition_dur, value.toInt())
            if (fromUser) {
                Prefs.setTransitionMs(this, value.toInt())
                playSoon()
            }
        }
    }

    private fun setupTrigger(cardId: Int, flag: Int, titleRes: Int, subRes: Int, icon: Int) {
        val card = findViewById<View>(cardId)
        Cards.bind(card, icon, getString(titleRes), getString(subRes))
        val sw = Cards.switchOf(card)
        sw.isChecked = Prefs.transitionTriggers(this) and flag != 0
        sw.setOnCheckedChangeListener { _, checked ->
            val current = Prefs.transitionTriggers(this)
            Prefs.setTransitionTriggers(this, if (checked) current or flag else current and flag.inv())
        }
    }

    private fun setupTriggers() {
        setupTrigger(R.id.cardTrigWake, Trigger.WAKE, R.string.trig_wake_title, R.string.trig_wake_sub, R.drawable.ic_bolt)
        setupTrigger(R.id.cardTrigUnlock, Trigger.UNLOCK, R.string.trig_unlock_title, R.string.trig_unlock_sub, R.drawable.ic_lock)
        setupTrigger(R.id.cardTrigReturn, Trigger.RETURN, R.string.trig_return_title, R.string.trig_return_sub, R.drawable.ic_home)
    }

    // ---------- жизненный цикл ----------

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.let {
            it.clearVideoSurface()
            it.release()
        }
        player = null
        renderer?.detach()
        renderer?.release()
        renderer = null
        super.onDestroy()
    }
}
