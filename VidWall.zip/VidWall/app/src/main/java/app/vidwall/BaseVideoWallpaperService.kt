package app.vidwall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.database.ContentObserver
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.Surface
import android.view.SurfaceHolder
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer

/**
 * Видеообои. Видео декодирует ExoPlayer, а кадр рисует [GlRenderer]: так мы сами управляем
 * масштабом и сдвигом и не зависим от того, как конкретный телефон растягивает видео.
 *
 * Пауза, когда обои не видны или включено энергосбережение; плеер освобождается через 30 с невидимости.
 * Ошибки воспроизведения перехватываются: сбойное видео пропускается.
 */
abstract class BaseVideoWallpaperService(private val profile: Profile) : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    private class Slot(val key: String, val item: MediaItem, val entry: VideoEntry)

    private inner class VideoEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var renderer: GlRenderer? = null
        private var videoSurface: Surface? = null
        private var player: ExoPlayer? = null
        private var surfaceAttached = false
        private var isVisibleNow = false
        private var errorStreak = 0
        private var lastKeys: List<String> = emptyList()
        private var slotById: Map<String, Slot> = emptyMap()
        private var introArmed = true
        private var receiverRegistered = false

        // Параллакс от наклона
        private val sensorManager: SensorManager by lazy {
            getSystemService(Context.SENSOR_SERVICE) as SensorManager
        }
        private var sensorActive = false
        private var haveBase = false
        private var baseX = 0f
        private var baseZ = 0f
        private var lastSensorNs = 0L
        private var parallaxStrength = 0f

        private val sensorListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val ax = event.values[0]
                val az = event.values[2]
                if (!haveBase) {
                    baseX = ax
                    baseZ = az
                    lastSensorNs = event.timestamp
                    haveBase = true
                }
                // «Нулевое» положение медленно подстраивается под то, как вы держите телефон,
                // поэтому реагируем на движение, а не на угол.
                val dt = ((event.timestamp - lastSensorNs) / 1e9f).coerceIn(0f, 0.5f)
                lastSensorNs = event.timestamp
                val k = dt / (BASE_TAU_SEC + dt)
                baseX += (ax - baseX) * k
                baseZ += (az - baseZ) * k
                val range = SensorManager.GRAVITY_EARTH * 0.5f
                val nx = ((ax - baseX) / range).coerceIn(-1f, 1f)
                val nz = ((az - baseZ) / range).coerceIn(-1f, 1f)
                renderer?.setParallax(parallaxStrength, nx, nz)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        private val powerManager: PowerManager by lazy {
            getSystemService(Context.POWER_SERVICE) as PowerManager
        }

        private val releaseRunnable = Runnable { releasePlayer() }
        private val reloadRunnable = Runnable {
            if (isVisibleNow) {
                refreshPlaylist()
                updatePlaying()
            }
        }

        private val mediaObserver = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) = scheduleReload()
        }
        private val prefsListener =
            SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> scheduleReload() }
        private val systemReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                    // Следующий показ обоев (включение экрана или разблокировка) начнётся с перехода.
                    introArmed = true
                } else {
                    updatePlaying()
                }
            }
        }

        private fun scheduleReload() {
            handler.removeCallbacks(reloadRunnable)
            handler.postDelayed(reloadRunnable, RELOAD_DELAY_MS)
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            renderer = GlRenderer { surface -> onVideoSurface(surface) }
            try {
                contentResolver.registerContentObserver(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver
                )
            } catch (e: Exception) {
                Log.w(TAG, "registerContentObserver failed", e)
            }
            try {
                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_SCREEN_OFF)
                    addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                }
                registerReceiver(systemReceiver, filter)
                receiverRegistered = true
            } catch (e: Exception) {
                Log.w(TAG, "registerReceiver failed", e)
            }
            Prefs.get(applicationContext).registerOnSharedPreferenceChangeListener(prefsListener)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            val r = renderer ?: return
            if (!surfaceAttached) {
                surfaceAttached = true
                r.attach(holder.surface, width, height)
            } else {
                r.resize(width, height)
            }
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            super.onSurfaceRedrawNeeded(holder)
            renderer?.requestDraw()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            renderer?.detach()
            surfaceAttached = false
            videoSurface = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            isVisibleNow = visible
            handler.removeCallbacks(releaseRunnable)
            if (visible) {
                if (introArmed && !isPreview) {
                    introArmed = false
                    startIntro()
                }
                startPlayback()
            } else {
                player?.pause()
                try {
                    updateSensors()
                } catch (e: Exception) {
                    Log.w(TAG, "updateSensors failed", e)
                }
                handler.postDelayed(releaseRunnable, RELEASE_DELAY_MS)
            }
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            try {
                contentResolver.unregisterContentObserver(mediaObserver)
            } catch (e: Exception) {
                Log.w(TAG, "unregisterContentObserver failed", e)
            }
            if (receiverRegistered) {
                try {
                    unregisterReceiver(systemReceiver)
                } catch (e: Exception) {
                    Log.w(TAG, "unregisterReceiver failed", e)
                }
            }
            Prefs.get(applicationContext).unregisterOnSharedPreferenceChangeListener(prefsListener)
            if (sensorActive) {
                sensorManager.unregisterListener(sensorListener)
                sensorActive = false
            }
            releasePlayer()
            renderer?.detach()
            renderer?.release()
            renderer = null
            super.onDestroy()
        }

        /** Рендерер сообщает, что внутренняя поверхность для плеера готова (или пропала). */
        private fun onVideoSurface(surface: Surface?) {
            videoSurface = if (surface != null && surface.isValid) surface else null
            if (videoSurface == null) {
                releasePlayer()
            } else if (isVisibleNow) {
                startPlayback()
            }
        }

        private fun startIntro() {
            val type = Prefs.transition(applicationContext)
            if (type != Transition.NONE) {
                renderer?.startIntro(type, Prefs.transitionMs(applicationContext).toLong())
            }
        }

        private fun shouldPlay(): Boolean {
            if (!isVisibleNow) return false
            if (Prefs.pauseOnPowerSave(applicationContext) && powerManager.isPowerSaveMode) return false
            return true
        }

        /** Включает датчик наклона, только пока обои видны и играют, и только если параллакс включён. */
        private fun updateSensors() {
            parallaxStrength = Prefs.parallax(applicationContext) / 100f
            val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val want = shouldPlay() && parallaxStrength > 0f && accel != null
            if (want && !sensorActive) {
                haveBase = false
                sensorActive = sensorManager.registerListener(sensorListener, accel, SensorManager.SENSOR_DELAY_UI)
            } else if (!want && sensorActive) {
                sensorManager.unregisterListener(sensorListener)
                sensorActive = false
            }
            if (!sensorActive) renderer?.setParallax(parallaxStrength, 0f, 0f)
        }

        private fun updatePlaying() {
            try {
                updateSensors()
            } catch (e: Exception) {
                Log.w(TAG, "updateSensors failed", e)
            }
            val p = player ?: return
            try {
                if (shouldPlay()) {
                    if (p.mediaItemCount > 0 && p.playbackState == Player.STATE_IDLE) p.prepare()
                    p.playWhenReady = true
                } else {
                    p.pause()
                }
            } catch (e: Exception) {
                Log.w(TAG, "updatePlaying failed", e)
            }
        }

        private fun startPlayback() {
            val surface = videoSurface ?: return
            try {
                errorStreak = 0
                val p = player ?: createPlayer().also {
                    player = it
                    it.setVideoSurface(surface)
                }
                refreshPlaylist()
                updatePlaying()
            } catch (e: Exception) {
                Log.e(TAG, "startPlayback failed", e)
                releasePlayer()
            }
        }

        private fun createPlayer(): ExoPlayer {
            val p = ExoPlayer.Builder(applicationContext).build()
            p.volume = 0f
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                .build()
            p.addListener(object : Player.Listener {
                override fun onRenderedFirstFrame() {
                    errorStreak = 0
                }

                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    renderer?.setVideoSize(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    applyItemSettings(p, mediaItem)
                }

                override fun onPlayerError(error: PlaybackException) {
                    handleError(p, error)
                }
            })
            return p
        }

        /** Скорость и кадрирование берутся из настроек текущего ролика. */
        private fun applyItemSettings(p: ExoPlayer, item: MediaItem?) {
            val entry = item?.let { slotById[it.mediaId]?.entry }
            try {
                p.setPlaybackSpeed(entry?.speed ?: 1f)
                renderer?.setFraming(entry?.zoom ?: 1f, entry?.panX ?: 0f, entry?.panY ?: 0f)
            } catch (e: Exception) {
                Log.w(TAG, "applyItemSettings failed", e)
            }
        }

        private fun handleError(p: ExoPlayer, error: PlaybackException) {
            Log.w(TAG, "Playback error", error)
            errorStreak++
            if (errorStreak > p.mediaItemCount.coerceAtLeast(1) + 1) {
                Log.e(TAG, "Too many consecutive errors, giving up until next show")
                return
            }
            try {
                if (p.mediaItemCount > 1) p.seekToNextMediaItem()
                p.prepare()
            } catch (e: Exception) {
                Log.e(TAG, "Recovery failed", e)
            }
        }

        private fun slotOf(e: VideoEntry): Slot {
            val b = MediaItem.Builder()
                .setUri(VideoRepository.uriOf(e.id))
                .setMediaId(e.id.toString())
            if (e.startMs > 0 || e.endMs > 0) {
                val c = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(e.startMs)
                if (e.endMs > e.startMs) c.setEndPositionMs(e.endMs)
                b.setClippingConfiguration(c.build())
            }
            val key = "${e.id}:${e.startMs}:${e.endMs}:${e.speed}:${e.zoom}:${e.panX}:${e.panY}"
            return Slot(key, b.build(), e)
        }

        /** Пересобирает плейлист, только если набор или настройки видео изменились. */
        private fun refreshPlaylist() {
            val p = player ?: return
            val ctx = applicationContext
            val entries = Prefs.entries(ctx, Prefs.effective(ctx, profile))
            val slots = if (entries.isNotEmpty()) {
                entries.map { slotOf(it) }
            } else {
                VideoRepository.queryAll(ctx).map { slotOf(VideoEntry(it.id)) }
            }
            p.shuffleModeEnabled = Prefs.shuffle(ctx)
            slotById = slots.associateBy { it.item.mediaId }
            if (slots.isEmpty()) {
                lastKeys = emptyList()
                p.stop()
                p.clearMediaItems()
                return
            }
            p.repeatMode = if (slots.size == 1) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_ALL

            val keys = slots.map { it.key }
            if (keys == lastKeys && p.mediaItemCount == slots.size) {
                applyItemSettings(p, p.currentMediaItem)
                return
            }
            val playingId = p.currentMediaItem?.mediaId
            val index = slots.indexOfFirst { it.item.mediaId == playingId }
            lastKeys = keys
            val items = slots.map { it.item }
            if (index >= 0) {
                p.setMediaItems(items, index, p.currentPosition)
            } else {
                p.setMediaItems(items)
            }
            p.prepare()
        }

        private fun releasePlayer() {
            val p = player ?: return
            player = null
            lastKeys = emptyList()
            try {
                p.clearVideoSurface()
                p.release()
            } catch (e: Exception) {
                Log.w(TAG, "release failed", e)
            }
        }
    }

    private companion object {
        const val TAG = "VidWall"
        const val RELOAD_DELAY_MS = 1500L
        const val RELEASE_DELAY_MS = 30_000L
        const val BASE_TAU_SEC = 2.5f
    }
}
