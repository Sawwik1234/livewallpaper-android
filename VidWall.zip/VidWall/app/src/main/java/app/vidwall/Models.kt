package app.vidwall

import java.util.Locale

/** Для какого экрана настроен набор видео. */
enum class Profile(val key: String) {
    HOME("home"),
    LOCK("lock");

    companion object {
        fun of(key: String?): Profile = if (key == LOCK.key) LOCK else HOME
    }
}

/** Эффекты перехода (появления видео). Номера совпадают с номерами в шейдере. */
object Transition {
    const val NONE = 0
    const val FADE = 1
    const val ZOOM_IN = 2
    const val ZOOM_OUT = 3
    const val SLIDE = 4
    const val WIPE = 5
    const val SCAN = 6
    const val IRIS = 7
    const val RADIAL = 8
    const val BLINDS = 9
    const val PIXELATE = 10
    const val DISSOLVE = 11
    const val BLUR = 12
    const val RIPPLE = 13
    const val WAVE = 14
    const val SWIRL = 15
    const val SPIN = 16
    const val GLITCH = 17
    const val FLASH = 18
    const val MELT = 19
    const val SQUARES = 20
    const val KALEIDO = 21
    const val STATIC = 22
    const val PINWHEEL = 23
    const val ZOOM_BLUR = 24

    val all: List<TransitionInfo> = listOf(
        TransitionInfo(NONE, R.string.tr_none, false),
        TransitionInfo(FADE, R.string.tr_fade, false),
        TransitionInfo(ZOOM_IN, R.string.tr_zoom_in, false),
        TransitionInfo(ZOOM_OUT, R.string.tr_zoom_out, false),
        TransitionInfo(SLIDE, R.string.tr_slide, true),
        TransitionInfo(WIPE, R.string.tr_wipe, true),
        TransitionInfo(SCAN, R.string.tr_scan, true),
        TransitionInfo(IRIS, R.string.tr_iris, true),
        TransitionInfo(RADIAL, R.string.tr_radial, false),
        TransitionInfo(PINWHEEL, R.string.tr_pinwheel, false),
        TransitionInfo(BLINDS, R.string.tr_blinds, true),
        TransitionInfo(PIXELATE, R.string.tr_pixelate, false),
        TransitionInfo(DISSOLVE, R.string.tr_dissolve, false),
        TransitionInfo(SQUARES, R.string.tr_squares, false),
        TransitionInfo(BLUR, R.string.tr_blur, false),
        TransitionInfo(ZOOM_BLUR, R.string.tr_zoom_blur, false),
        TransitionInfo(RIPPLE, R.string.tr_ripple, false),
        TransitionInfo(WAVE, R.string.tr_wave, false),
        TransitionInfo(SWIRL, R.string.tr_swirl, false),
        TransitionInfo(SPIN, R.string.tr_spin, false),
        TransitionInfo(KALEIDO, R.string.tr_kaleido, false),
        TransitionInfo(GLITCH, R.string.tr_glitch, false),
        TransitionInfo(STATIC, R.string.tr_static, false),
        TransitionInfo(MELT, R.string.tr_melt, false),
        TransitionInfo(FLASH, R.string.tr_flash, false)
    )

    fun info(id: Int): TransitionInfo = all.firstOrNull { it.id == id } ?: all[0]
}

data class TransitionInfo(val id: Int, val nameRes: Int, val usesDirection: Boolean)

/** Кривая скорости перехода. */
object Easing {
    const val SMOOTH = 0
    const val FAST_START = 1
    const val SLOW_START = 2
    const val LINEAR = 3
    val labels = listOf(R.string.ease_smooth, R.string.ease_fast, R.string.ease_slow, R.string.ease_linear)
}

/** Откуда появляется видео: для эффектов с направлением. */
object Dir {
    const val CENTER = 0
    const val LEFT = 1
    const val RIGHT = 2
    const val TOP = 3
    const val BOTTOM = 4
    val labels = listOf(R.string.dir_center, R.string.dir_left, R.string.dir_right, R.string.dir_top, R.string.dir_bottom)
}

/** Когда запускать переход (набор флагов). */
object Trigger {
    const val WAKE = 1
    const val UNLOCK = 2
    const val RETURN = 4
}

data class TransitionConfig(val type: Int, val durationMs: Long, val easing: Int, val dir: Int)

data class VideoInfo(val id: Long, val name: String, val durationMs: Long)

/**
 * Настройки одного выбранного видео.
 * endMs = 0 означает «до конца».
 * zoom = 1 означает «заполнить экран»; panX и panY от -1 до 1 сдвигают кадр в пределах видимого запаса.
 */
data class VideoEntry(
    val id: Long,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val speed: Float = 1f,
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f
) {
    val isFramed: Boolean get() = zoom != 1f || panX != 0f || panY != 0f
}

fun formatTime(ms: Long): String {
    val total = ms / 1000
    return String.format(Locale.ROOT, "%d:%02d", total / 60, total % 60)
}
