package app.vidwall

import java.util.Locale

/** Для какого экрана настроен набор видео. */
enum class Profile(val key: String) {
    HOME("home"),
    LOCK("lock");

    companion object {
        fun of(key: String?): Profile = if (key == LOCK.key) LOCK else HOME
    }
}

object Transition {
    const val NONE = 0
    const val FADE = 1
    const val ZOOM = 2
}

data class VideoInfo(val id: Long, val name: String, val durationMs: Long)

/**
 * Настройки одного выбранного видео.
 * endMs = 0 означает «до конца».
 * zoom = 1 означает «заполнить экран»; panX и panY от -1 до 1 сдвигают кадр в пределах видимого запаса.
 */
data class VideoEntry(
    val id: Long,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val speed: Float = 1f,
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f
) {
    val isFramed: Boolean get() = zoom != 1f || panX != 0f || panY != 0f
}

fun formatTime(ms: Long): String {
    val total = ms / 1000
    return String.format(Locale.ROOT, "%d:%02d", total / 60, total % 60)
}
