package app.vidwall

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Математика кадрирования. Все величины в нормализованных координатах экрана (от -1 до 1). */
object FramingMath {
    /** Размер квадрата видео для режима «заполнить»: хотя бы по одной оси он равен 1. */
    fun coverScale(videoAspect: Float, viewAspect: Float): Pair<Float, Float> =
        if (videoAspect > viewAspect) Pair(videoAspect / viewAspect, 1f)
        else Pair(1f, viewAspect / videoAspect)

    /** Масштаб, при котором видео целиком помещается в экран (с чёрными полосами). */
    fun containZoom(videoAspect: Float, viewAspect: Float): Float {
        val (bx, by) = coverScale(videoAspect, viewAspect)
        return 1f / maxOf(bx, by)
    }

    /** На сколько можно сдвинуть кадр по оси, не открывая пустоту. */
    fun maxShift(base: Float, zoom: Float): Float = maxOf(0f, base * zoom - 1f)
}

/**
 * Рисует видео через OpenGL на поверхность обоев (или превью в редакторе).
 * Сам решает, как вписать и обрезать кадр, поэтому видео никогда не растягивается.
 * Умеет масштаб, сдвиг, параллакс и переходы (эффекты появления) на шейдере.
 *
 * Плеер рисует во внутреннюю поверхность этого объекта, её отдаёт [onVideoSurface] (в главном потоке).
 */
class GlRenderer(private val onVideoSurface: (Surface?) -> Unit) {

    private val thread = HandlerThread("VidWall-GL").also { it.start() }
    private val handler = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())

    // Всё ниже трогается только из GL-потока.
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var uXform = 0
    private var uTexMatrix = 0
    private var uMode = 0
    private var uP = 0
    private var uDir = 0
    private var uRes = 0
    private var uTex = 0
    private var texId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var videoSurface: Surface? = null

    private var viewW = 0
    private var viewH = 0
    private var videoAspect = 0f
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var frameAvailable = false
    private var haveFrame = false

    // Параллакс: цель приходит от датчиков, текущее значение плавно догоняет цель.
    private var parallaxM = 0f
    private var parallaxTargetX = 0f
    private var parallaxTargetY = 0f
    private var parallaxX = 0f
    private var parallaxY = 0f

    private var introType = Transition.NONE
    private var introEasing = 0
    private var introDir = 0
    private var introStart = 0L
    private var introMs = 0L

    private val texMatrix = FloatArray(16)

    private val tick = Runnable { draw() }

    private val vertices: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }

    init {
        Matrix.setIdentityM(texMatrix, 0)
    }

    // ---------- публичный интерфейс (из любого потока) ----------

    fun attach(surface: Surface, width: Int, height: Int) {
        handler.post { initEgl(surface, width, height) }
    }

    fun resize(width: Int, height: Int) {
        handler.post {
            viewW = width
            viewH = height
            draw()
        }
    }

    /** Освобождает графику и ждёт окончания: после возврата поверхность можно уничтожать. */
    fun detach() {
        val latch = CountDownLatch(1)
        val posted = handler.post {
            try {
                releaseEgl()
            } finally {
                latch.countDown()
            }
        }
        if (posted) latch.await(1, TimeUnit.SECONDS)
    }

    fun setVideoSize(width: Int, height: Int, pixelRatio: Float) {
        handler.post {
            videoAspect = if (width > 0 && height > 0) width * pixelRatio / height else 0f
            draw()
        }
    }

    fun setFraming(zoom: Float, panX: Float, panY: Float) {
        handler.post {
            this.zoom = zoom
            this.panX = panX
            this.panY = panY
            draw()
        }
    }

    /**
     * Параллакс от наклона. strength от 0 до 1, x и y от -1 до 1.
     * При strength > 0 видео слегка приближается, чтобы при сдвиге не открывались края.
     */
    fun setParallax(strength: Float, x: Float, y: Float) {
        handler.post {
            parallaxM = strength.coerceIn(0f, 1f) * MAX_PARALLAX
            parallaxTargetX = x.coerceIn(-1f, 1f)
            parallaxTargetY = y.coerceIn(-1f, 1f)
            if (parallaxM <= 0f) {
                parallaxX = 0f
                parallaxY = 0f
            }
        }
    }

    /** Запускает эффект появления (переход) с текущего момента. */
    fun startIntro(config: TransitionConfig) {
        handler.post {
            introType = config.type
            introEasing = config.easing
            introDir = config.dir
            introMs = config.durationMs
            introStart = SystemClock.uptimeMillis()
            handler.removeCallbacks(tick)
            draw()
        }
    }

    fun requestDraw() {
        handler.post { draw() }
    }

    fun release() {
        handler.post { releaseEgl() }
        thread.quitSafely()
    }

    // ---------- EGL и шейдеры ----------

    private fun initEgl(surface: Surface, width: Int, height: Int) {
        try {
            releaseEgl()
            viewW = width
            viewH = height

            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            check(display != EGL14.EGL_NO_DISPLAY) { "no display" }
            val version = IntArray(2)
            check(EGL14.eglInitialize(display, version, 0, version, 1)) { "eglInitialize" }
            eglDisplay = display

            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            check(EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0) && numConfigs[0] > 0) {
                "eglChooseConfig"
            }
            val config = configs[0]

            val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            val context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
            check(context != EGL14.EGL_NO_CONTEXT) { "eglCreateContext" }
            eglContext = context

            val windowSurface = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
            check(windowSurface != EGL14.EGL_NO_SURFACE) { "eglCreateWindowSurface" }
            eglSurface = windowSurface

            check(EGL14.eglMakeCurrent(display, windowSurface, windowSurface, context)) { "eglMakeCurrent" }

            buildProgram()
            createVideoTexture()
            draw()
        } catch (e: Exception) {
            Log.e(TAG, "initEgl failed", e)
            releaseEgl()
        }
    }

    private fun createVideoTexture() {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texId = ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(texId)
        st.setOnFrameAvailableListener(
            SurfaceTexture.OnFrameAvailableListener {
                frameAvailable = true
                draw()
            },
            handler
        )
        surfaceTexture = st
        val s = Surface(st)
        videoSurface = s
        main.post { onVideoSurface(s) }
    }

    /** Собирает полный шейдер с эффектами; если телефон его не принял, запасной простой (без эффектов). */
    private fun buildProgram() {
        program = try {
            link(VERTEX_SHADER, FRAGMENT_SHADER)
        } catch (e: Exception) {
            Log.e(TAG, "Full shader failed, using simple one", e)
            link(VERTEX_SHADER, FRAGMENT_SIMPLE)
        }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uXform = GLES20.glGetUniformLocation(program, "uXform")
        uTexMatrix = GLES20.glGetUniformLocation(program, "uTexMatrix")
        uMode = GLES20.glGetUniformLocation(program, "uMode")
        uP = GLES20.glGetUniformLocation(program, "uP")
        uDir = GLES20.glGetUniformLocation(program, "uDir")
        uRes = GLES20.glGetUniformLocation(program, "uRes")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
    }

    private fun link(vertexSource: String, fragmentSource: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        val status = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(p)
            GLES20.glDeleteProgram(p)
            error("link: $log")
        }
        return p
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            error("shader: $log")
        }
        return shader
    }

    // ---------- отрисовка ----------

    private fun ease(t: Float): Float = when (introEasing) {
        Easing.FAST_START -> 1f - (1f - t) * (1f - t) * (1f - t)
        Easing.SLOW_START -> t * t
        Easing.LINEAR -> t
        else -> t * t * (3f - 2f * t)
    }

    /** Возвращает номер активного эффекта (0, если переход не идёт) и его прогресс от 0 до 1. */
    private fun introUniforms(): Pair<Int, Float> {
        if (introType == Transition.NONE || introMs <= 0L) return Pair(0, 1f)
        val raw = ((SystemClock.uptimeMillis() - introStart).toFloat() / introMs).coerceIn(0f, 1f)
        if (raw >= 1f) return Pair(0, 1f)
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 16)
        return Pair(introType, ease(raw))
    }

    private fun draw() {
        if (eglSurface == EGL14.EGL_NO_SURFACE || viewW <= 0 || viewH <= 0) return
        try {
            val st = surfaceTexture
            if (frameAvailable && st != null) {
                frameAvailable = false
                st.updateTexImage()
                st.getTransformMatrix(texMatrix)
                haveFrame = true
            }

            GLES20.glViewport(0, 0, viewW, viewH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

            if (haveFrame && videoAspect > 0f) {
                val (mode, progress) = introUniforms()
                val viewAspect = viewW.toFloat() / viewH
                val (bx, by) = FramingMath.coverScale(videoAspect, viewAspect)
                val m = parallaxM
                if (m > 0f) {
                    parallaxX += (parallaxTargetX - parallaxX) * 0.25f
                    parallaxY += (parallaxTargetY - parallaxY) * 0.25f
                }
                val extra = 1f + m
                val tx = panX.coerceIn(-1f, 1f) * FramingMath.maxShift(bx, zoom) + parallaxX * m
                val ty = panY.coerceIn(-1f, 1f) * FramingMath.maxShift(by, zoom) + parallaxY * m

                GLES20.glUseProgram(program)
                GLES20.glUniform4f(uXform, bx * zoom * extra, by * zoom * extra, tx, ty)
                GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, texMatrix, 0)
                GLES20.glUniform1f(uMode, mode.toFloat())
                GLES20.glUniform1f(uP, progress)
                GLES20.glUniform1f(uDir, introDir.toFloat())
                GLES20.glUniform2f(uRes, viewW.toFloat(), viewH.toFloat())
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
                GLES20.glUniform1i(uTex, 0)

                vertices.position(0)
                GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, vertices)
                GLES20.glEnableVertexAttribArray(aPos)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GLES20.glDisableVertexAttribArray(aPos)
            }

            if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) {
                Log.w(TAG, "eglSwapBuffers failed: ${EGL14.eglGetError()}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "draw failed", e)
        }
    }

    private fun releaseEgl() {
        handler.removeCallbacks(tick)
        val hadSurface = videoSurface != null
        try {
            videoSurface?.release()
        } catch (e: Exception) {
            Log.w(TAG, "surface release failed", e)
        }
        videoSurface = null
        try {
            surfaceTexture?.release()
        } catch (e: Exception) {
            Log.w(TAG, "surfaceTexture release failed", e)
        }
        surfaceTexture = null

        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            if (eglSurface != EGL14.EGL_NO_SURFACE && eglContext != EGL14.EGL_NO_CONTEXT) {
                // Пока контекст активен, удаляем объекты OpenGL.
                if (texId != 0) GLES20.glDeleteTextures(1, intArrayOf(texId), 0)
                if (program != 0) GLES20.glDeleteProgram(program)
            }
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
            // eglTerminate не вызываем: дисплей общий для всего процесса.
        }
        texId = 0
        program = 0
        eglSurface = EGL14.EGL_NO_SURFACE
        eglContext = EGL14.EGL_NO_CONTEXT
        eglDisplay = EGL14.EGL_NO_DISPLAY
        frameAvailable = false
        haveFrame = false
        if (hadSurface) main.post { onVideoSurface(null) }
    }

    private companion object {
        const val TAG = "VidWall"

        /** Максимальный сдвиг при параллаксе на 100% (в долях половины экрана). */
        const val MAX_PARALLAX = 0.06f

        const val VERTEX_SHADER = """attribute vec4 aPos;
varying vec2 vScr;
void main() {
    gl_Position = aPos;
    vScr = aPos.xy * 0.5 + 0.5;
}
"""

        const val FRAGMENT_SHADER = """#extension GL_OES_EGL_image_external : require
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vScr;
uniform samplerExternalOES uTex;
uniform mat4 uTexMatrix;
uniform vec4 uXform;
uniform float uMode;
uniform float uP;
uniform float uDir;
uniform vec2 uRes;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 videoAt(vec2 scr) {
    vec2 q = ((scr * 2.0 - 1.0) - uXform.zw) / uXform.xy;
    if (abs(q.x) > 1.0 || abs(q.y) > 1.0) {
        return vec3(0.0);
    }
    vec2 t = (uTexMatrix * vec4(q * 0.5 + 0.5, 0.0, 1.0)).xy;
    return texture2D(uTex, t).rgb;
}

// Откуда появляется видео: 0 центр, 1 слева, 2 справа, 3 сверху, 4 снизу.
float along(vec2 uv, float dir) {
    if (dir < 0.5) { return abs(uv.x - 0.5) * 2.0; }
    if (dir < 1.5) { return uv.x; }
    if (dir < 2.5) { return 1.0 - uv.x; }
    if (dir < 3.5) { return 1.0 - uv.y; }
    return uv.y;
}

vec2 enterVec(float dir) {
    if (dir < 0.5) { return vec2(0.0, 1.0); }
    if (dir < 1.5) { return vec2(-1.0, 0.0); }
    if (dir < 2.5) { return vec2(1.0, 0.0); }
    if (dir < 3.5) { return vec2(0.0, 1.0); }
    return vec2(0.0, -1.0);
}

vec2 originOf(float dir) {
    if (dir < 0.5) { return vec2(0.5, 0.5); }
    if (dir < 1.5) { return vec2(0.0, 0.5); }
    if (dir < 2.5) { return vec2(1.0, 0.5); }
    if (dir < 3.5) { return vec2(0.5, 1.0); }
    return vec2(0.5, 0.0);
}

void main() {
    vec2 uv = vScr;
    float p = uP;
    float asp = uRes.x / uRes.y;
    int m = int(uMode + 0.5);
    vec3 col = vec3(0.0);
    float a = 1.0;

    if (m == 1) {
        col = videoAt(uv);
        a = p;
    } else if (m == 2) {
        col = videoAt((uv - 0.5) / mix(0.8, 1.0, p) + 0.5);
        a = p;
    } else if (m == 3) {
        col = videoAt((uv - 0.5) / mix(1.25, 1.0, p) + 0.5);
        a = p;
    } else if (m == 4) {
        col = videoAt(uv - enterVec(uDir) * (1.0 - p));
    } else if (m == 5 || m == 6) {
        float soft = 0.08;
        if (m == 6) { soft = 0.02; }
        float edge = p * (1.0 + soft);
        float al = along(uv, uDir);
        a = 1.0 - smoothstep(edge - soft, edge, al);
        col = videoAt(uv);
        if (m == 6) {
            float line = 1.0 - smoothstep(0.0, 0.03, abs(al - edge));
            col = col * a + vec3(0.6, 0.85, 1.0) * line * (1.0 - p);
            a = 1.0;
        }
    } else if (m == 7) {
        vec2 o = originOf(uDir);
        vec2 dv = (uv - o) * vec2(asp, 1.0);
        float maxD = length(max(o, 1.0 - o) * vec2(asp, 1.0));
        float edge = p * 1.1 * maxD;
        a = 1.0 - smoothstep(edge - 0.1 * maxD, edge, length(dv));
        col = videoAt(uv);
    } else if (m == 8) {
        vec2 dv = uv - 0.5;
        float ang = fract((1.5707963 - atan(dv.y, dv.x)) / 6.2831853);
        float edge = p * 1.04;
        a = 1.0 - smoothstep(edge - 0.04, edge, ang);
        col = videoAt(uv);
    } else if (m == 9) {
        float bands = 10.0;
        float loc = fract(uv.y * bands);
        if (uDir > 0.5 && uDir < 2.5) { loc = fract(uv.x * bands); }
        float edge = p * 1.06;
        a = 1.0 - smoothstep(edge - 0.06, edge, loc);
        col = videoAt(uv);
    } else if (m == 10) {
        float px = max(1.0, mix(90.0, 1.0, p));
        vec2 cell = (floor(uv * uRes / px) + 0.5) * px / uRes;
        col = videoAt(cell);
        a = smoothstep(0.0, 0.5, p);
    } else if (m == 11 || m == 20) {
        float blockPx = 6.0;
        if (m == 20) { blockPx = 90.0; }
        float n = hash(floor(uv * uRes / blockPx));
        float edge = p * 1.15;
        a = 1.0 - smoothstep(edge - 0.15, edge, n);
        if (m == 20) { a = step(n, p); }
        col = videoAt(uv);
    } else if (m == 12) {
        float r = (1.0 - p) * 0.05;
        vec2 rr = vec2(r / asp, r);
        vec3 sum = videoAt(uv) * 0.2;
        for (int i = 0; i < 8; i++) {
            float ang = float(i) * 0.7853982;
            vec2 d = vec2(cos(ang), sin(ang));
            sum += videoAt(uv + d * rr * 0.5) * 0.05;
            sum += videoAt(uv + d * rr) * 0.05;
        }
        col = sum;
        a = smoothstep(0.0, 0.7, p);
    } else if (m == 13) {
        vec2 dv = (uv - 0.5) * vec2(asp, 1.0);
        float dist = length(dv);
        float wave = sin(dist * 45.0 - p * 20.0) * (1.0 - p) * 0.02;
        vec2 dir = dv / (dist + 0.0001);
        col = videoAt(uv + dir * wave * vec2(1.0 / asp, 1.0));
        a = smoothstep(0.0, 0.6, p);
    } else if (m == 14) {
        float off = sin(uv.y * 18.0 + p * 10.0) * 0.05 * (1.0 - p);
        col = videoAt(uv + vec2(off, 0.0));
        a = smoothstep(0.0, 0.7, p);
    } else if (m == 15) {
        vec2 dv = (uv - 0.5) * vec2(asp, 1.0);
        float r = length(dv);
        float ang = (1.0 - p) * 5.0 * exp(-r * 3.0);
        float c = cos(ang);
        float s = sin(ang);
        dv = vec2(c * dv.x - s * dv.y, s * dv.x + c * dv.y);
        col = videoAt(dv / vec2(asp, 1.0) + 0.5);
        a = smoothstep(0.0, 0.6, p);
    } else if (m == 16) {
        vec2 dv = (uv - 0.5) * vec2(asp, 1.0);
        float ang = (1.0 - p) * 0.6;
        float c = cos(ang);
        float s = sin(ang);
        dv = vec2(c * dv.x - s * dv.y, s * dv.x + c * dv.y) / mix(0.8, 1.0, p);
        col = videoAt(dv / vec2(asp, 1.0) + 0.5);
        a = p;
    } else if (m == 17) {
        float k = 1.0 - p;
        float row = floor(uv.y * 28.0);
        float n = hash(vec2(row, floor(p * 14.0)));
        float shift = (n - 0.5) * 0.18 * k * step(0.55, n);
        float split = 0.02 * k;
        col = vec3(
            videoAt(uv + vec2(shift + split, 0.0)).r,
            videoAt(uv + vec2(shift, 0.0)).g,
            videoAt(uv + vec2(shift - split, 0.0)).b
        );
        a = clamp(p * 2.0 + step(0.5, hash(vec2(floor(p * 16.0), 3.0))) * 0.5, 0.0, 1.0);
    } else if (m == 18) {
        col = mix(videoAt(uv), vec3(1.0), pow(1.0 - p, 2.0));
    } else if (m == 19) {
        float colIdx = floor(uv.x * 24.0);
        float delay = hash(vec2(colIdx, 7.0)) * 0.5;
        float lp = clamp((p - delay) / 0.5, 0.0, 1.0);
        lp = lp * lp * (3.0 - 2.0 * lp);
        col = videoAt(uv - vec2(0.0, 1.0 - lp));
    } else if (m == 21) {
        vec2 dv = (uv - 0.5) * vec2(asp, 1.0);
        float r = length(dv);
        float ang = atan(dv.y, dv.x);
        float seg = 6.2831853 / 6.0;
        ang = abs(mod(ang, seg) - seg * 0.5);
        vec2 kd = vec2(cos(ang), sin(ang)) * r;
        vec3 kc = videoAt(kd / vec2(asp, 1.0) + 0.5);
        col = mix(kc, videoAt(uv), smoothstep(0.1, 0.9, p));
        a = smoothstep(0.0, 0.4, p);
    } else if (m == 22) {
        float n = hash(floor(uv * uRes / 3.0) + vec2(floor(p * 24.0), 0.0));
        col = mix(vec3(n), videoAt(uv), smoothstep(0.1, 1.0, p));
        a = smoothstep(0.0, 0.2, p);
    } else if (m == 23) {
        vec2 dv = uv - 0.5;
        float ang = fract(atan(dv.y, dv.x) / 6.2831853 * 4.0);
        float edge = p * 1.05;
        a = 1.0 - smoothstep(edge - 0.05, edge, ang);
        col = videoAt(uv);
    } else if (m == 24) {
        float k = (1.0 - p) * 0.35;
        vec3 sum = vec3(0.0);
        for (int i = 0; i < 12; i++) {
            float t = float(i) / 11.0;
            sum += videoAt(uv + (vec2(0.5) - uv) * t * k);
        }
        col = sum / 12.0;
        a = smoothstep(0.0, 0.6, p);
    } else {
        col = videoAt(uv);
    }
    gl_FragColor = vec4(col * a, 1.0);
}
"""

        const val FRAGMENT_SIMPLE = """#extension GL_OES_EGL_image_external : require
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vScr;
uniform samplerExternalOES uTex;
uniform mat4 uTexMatrix;
uniform vec4 uXform;
uniform float uMode;
uniform float uP;
uniform float uDir;
uniform vec2 uRes;

void main() {
    vec2 q = ((vScr * 2.0 - 1.0) - uXform.zw) / uXform.xy;
    vec3 col = vec3(0.0);
    if (abs(q.x) <= 1.0 && abs(q.y) <= 1.0) {
        vec2 t = (uTexMatrix * vec4(q * 0.5 + 0.5, 0.0, 1.0)).xy;
        col = texture2D(uTex, t).rgb;
    }
    float a = 1.0;
    if (uMode > 0.5) { a = uP; }
    gl_FragColor = vec4(col * a, 1.0);
}
"""
    }
}
