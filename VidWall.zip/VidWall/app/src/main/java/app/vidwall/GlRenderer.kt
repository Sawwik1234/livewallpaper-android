package app.vidwall

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Математика кадрирования. Все величины в нормализованных координатах экрана (от -1 до 1). */
object FramingMath {
    /** Размер квадрата видео для режима «заполнить»: хотя бы по одной оси он равен 1. */
    fun coverScale(videoAspect: Float, viewAspect: Float): Pair<Float, Float> =
        if (videoAspect > viewAspect) Pair(videoAspect / viewAspect, 1f)
        else Pair(1f, viewAspect / videoAspect)

    /** Масштаб, при котором видео целиком помещается в экран (с чёрными полосами). */
    fun containZoom(videoAspect: Float, viewAspect: Float): Float {
        val (bx, by) = coverScale(videoAspect, viewAspect)
        return 1f / maxOf(bx, by)
    }

    /** На сколько можно сдвинуть кадр по оси, не открывая пустоту. */
    fun maxShift(base: Float, zoom: Float): Float = maxOf(0f, base * zoom - 1f)
}

/**
 * Рисует видео через OpenGL на поверхность обоев (или превью в редакторе).
 * Сам решает, как вписать и обрезать кадр, поэтому видео никогда не растягивается.
 * Умеет масштаб, сдвиг и плавное появление (переход при разблокировке).
 *
 * Плеер рисует во внутреннюю поверхность этого объекта, её отдаёт [onVideoSurface] (в главном потоке).
 */
class GlRenderer(private val onVideoSurface: (Surface?) -> Unit) {

    private val thread = HandlerThread("VidWall-GL").also { it.start() }
    private val handler = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())

    // Всё ниже трогается только из GL-потока.
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uMvp = 0
    private var uTexMatrix = 0
    private var uAlpha = 0
    private var uTex = 0
    private var texId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var videoSurface: Surface? = null

    private var viewW = 0
    private var viewH = 0
    private var videoAspect = 0f
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var frameAvailable = false
    private var haveFrame = false

    // Параллакс: цель приходит от датчиков, текущее значение плавно догоняет цель.
    private var parallaxM = 0f
    private var parallaxTargetX = 0f
    private var parallaxTargetY = 0f
    private var parallaxX = 0f
    private var parallaxY = 0f

    private var introType = Transition.NONE
    private var introStart = 0L
    private var introMs = 0L

    private val mvp = FloatArray(16)
    private val texMatrix = FloatArray(16)

    private val tick = Runnable { draw() }

    private val vertices: FloatBuffer = ByteBuffer.allocateDirect(16 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(
                floatArrayOf(
                    -1f, -1f, 0f, 0f,
                    1f, -1f, 1f, 0f,
                    -1f, 1f, 0f, 1f,
                    1f, 1f, 1f, 1f
                )
            )
            position(0)
        }

    init {
        Matrix.setIdentityM(mvp, 0)
        Matrix.setIdentityM(texMatrix, 0)
    }

    // ---------- публичный интерфейс (из любого потока) ----------

    fun attach(surface: Surface, width: Int, height: Int) {
        handler.post { initEgl(surface, width, height) }
    }

    fun resize(width: Int, height: Int) {
        handler.post {
            viewW = width
            viewH = height
            draw()
        }
    }

    /** Освобождает графику и ждёт окончания: после возврата поверхность можно уничтожать. */
    fun detach() {
        val latch = CountDownLatch(1)
        val posted = handler.post {
            try {
                releaseEgl()
            } finally {
                latch.countDown()
            }
        }
        if (posted) latch.await(1, TimeUnit.SECONDS)
    }

    fun setVideoSize(width: Int, height: Int, pixelRatio: Float) {
        handler.post {
            videoAspect = if (width > 0 && height > 0) width * pixelRatio / height else 0f
            draw()
        }
    }

    fun setFraming(zoom: Float, panX: Float, panY: Float) {
        handler.post {
            this.zoom = zoom
            this.panX = panX
            this.panY = panY
            draw()
        }
    }

    /**
     * Параллакс от наклона. strength от 0 до 1, x и y от -1 до 1.
     * При strength > 0 видео слегка приближается, чтобы при сдвиге не открывались края.
     */
    fun setParallax(strength: Float, x: Float, y: Float) {
        handler.post {
            parallaxM = strength.coerceIn(0f, 1f) * MAX_PARALLAX
            parallaxTargetX = x.coerceIn(-1f, 1f)
            parallaxTargetY = y.coerceIn(-1f, 1f)
            if (parallaxM <= 0f) {
                parallaxX = 0f
                parallaxY = 0f
            }
        }
    }

    fun startIntro(type: Int, durationMs: Long) {
        handler.post {
            introType = type
            introMs = durationMs
            introStart = SystemClock.uptimeMillis()
            handler.removeCallbacks(tick)
            draw()
        }
    }

    fun requestDraw() {
        handler.post { draw() }
    }

    fun release() {
        handler.post { releaseEgl() }
        thread.quitSafely()
    }

    // ---------- EGL и шейдеры ----------

    private fun initEgl(surface: Surface, width: Int, height: Int) {
        try {
            releaseEgl()
            viewW = width
            viewH = height

            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            check(display != EGL14.EGL_NO_DISPLAY) { "no display" }
            val version = IntArray(2)
            check(EGL14.eglInitialize(display, version, 0, version, 1)) { "eglInitialize" }
            eglDisplay = display

            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            check(EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0) && numConfigs[0] > 0) {
                "eglChooseConfig"
            }
            val config = configs[0]

            val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            val context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
            check(context != EGL14.EGL_NO_CONTEXT) { "eglCreateContext" }
            eglContext = context

            val windowSurface = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
            check(windowSurface != EGL14.EGL_NO_SURFACE) { "eglCreateWindowSurface" }
            eglSurface = windowSurface

            check(EGL14.eglMakeCurrent(display, windowSurface, windowSurface, context)) { "eglMakeCurrent" }

            buildProgram()
            createVideoTexture()
            draw()
        } catch (e: Exception) {
            Log.e(TAG, "initEgl failed", e)
            releaseEgl()
        }
    }

    private fun createVideoTexture() {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texId = ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(texId)
        st.setOnFrameAvailableListener(
            SurfaceTexture.OnFrameAvailableListener {
                frameAvailable = true
                draw()
            },
            handler
        )
        surfaceTexture = st
        val s = Surface(st)
        videoSurface = s
        main.post { onVideoSurface(s) }
    }

    private fun buildProgram() {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val status = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
        check(status[0] != 0) { "link: " + GLES20.glGetProgramInfoLog(p) }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        program = p
        aPos = GLES20.glGetAttribLocation(p, "aPos")
        aTex = GLES20.glGetAttribLocation(p, "aTex")
        uMvp = GLES20.glGetUniformLocation(p, "uMvp")
        uTexMatrix = GLES20.glGetUniformLocation(p, "uTexMatrix")
        uAlpha = GLES20.glGetUniformLocation(p, "uAlpha")
        uTex = GLES20.glGetUniformLocation(p, "uTex")
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        check(status[0] != 0) { "shader: " + GLES20.glGetShaderInfoLog(shader) }
        return shader
    }

    // ---------- отрисовка ----------

    /** Возвращает прозрачность и множитель масштаба для текущего момента перехода. */
    private fun introState(): Pair<Float, Float> {
        if (introType == Transition.NONE || introMs <= 0L) return Pair(1f, 1f)
        val p = ((SystemClock.uptimeMillis() - introStart).toFloat() / introMs).coerceIn(0f, 1f)
        val e = p * p * (3f - 2f * p)
        if (p < 1f) {
            handler.removeCallbacks(tick)
            handler.postDelayed(tick, 16)
        }
        return if (introType == Transition.ZOOM) Pair(e, 1f + 0.15f * (1f - e)) else Pair(e, 1f)
    }

    private fun draw() {
        if (eglSurface == EGL14.EGL_NO_SURFACE || viewW <= 0 || viewH <= 0) return
        try {
            val st = surfaceTexture
            if (frameAvailable && st != null) {
                frameAvailable = false
                st.updateTexImage()
                st.getTransformMatrix(texMatrix)
                haveFrame = true
            }

            GLES20.glViewport(0, 0, viewW, viewH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

            val (alpha, introScale) = introState()
            if (haveFrame && videoAspect > 0f && alpha > 0f) {
                val viewAspect = viewW.toFloat() / viewH
                val (bx, by) = FramingMath.coverScale(videoAspect, viewAspect)
                val tx = panX.coerceIn(-1f, 1f) * FramingMath.maxShift(bx, zoom)
                val ty = panY.coerceIn(-1f, 1f) * FramingMath.maxShift(by, zoom)
                val m = parallaxM
                if (m > 0f) {
                    parallaxX += (parallaxTargetX - parallaxX) * 0.25f
                    parallaxY += (parallaxTargetY - parallaxY) * 0.25f
                }
                val extra = 1f + m
                Matrix.setIdentityM(mvp, 0)
                Matrix.translateM(mvp, 0, tx + parallaxX * m, ty + parallaxY * m, 0f)
                Matrix.scaleM(mvp, 0, bx * zoom * introScale * extra, by * zoom * introScale * extra, 1f)

                GLES20.glUseProgram(program)
                GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
                GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, texMatrix, 0)
                GLES20.glUniform1f(uAlpha, alpha)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
                GLES20.glUniform1i(uTex, 0)

                vertices.position(0)
                GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, vertices)
                GLES20.glEnableVertexAttribArray(aPos)
                vertices.position(2)
                GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, vertices)
                GLES20.glEnableVertexAttribArray(aTex)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GLES20.glDisableVertexAttribArray(aPos)
                GLES20.glDisableVertexAttribArray(aTex)
            }

            if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) {
                Log.w(TAG, "eglSwapBuffers failed: ${EGL14.eglGetError()}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "draw failed", e)
        }
    }

    private fun releaseEgl() {
        handler.removeCallbacks(tick)
        val hadSurface = videoSurface != null
        try {
            videoSurface?.release()
        } catch (e: Exception) {
            Log.w(TAG, "surface release failed", e)
        }
        videoSurface = null
        try {
            surfaceTexture?.release()
        } catch (e: Exception) {
            Log.w(TAG, "surfaceTexture release failed", e)
        }
        surfaceTexture = null

        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            if (eglSurface != EGL14.EGL_NO_SURFACE && eglContext != EGL14.EGL_NO_CONTEXT) {
                // Пока контекст активен, удаляем объекты OpenGL.
                if (texId != 0) GLES20.glDeleteTextures(1, intArrayOf(texId), 0)
                if (program != 0) GLES20.glDeleteProgram(program)
            }
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
            // eglTerminate не вызываем: дисплей общий для всего процесса.
        }
        texId = 0
        program = 0
        eglSurface = EGL14.EGL_NO_SURFACE
        eglContext = EGL14.EGL_NO_CONTEXT
        eglDisplay = EGL14.EGL_NO_DISPLAY
        frameAvailable = false
        haveFrame = false
        if (hadSurface) main.post { onVideoSurface(null) }
    }

    private companion object {
        const val TAG = "VidWall"

        /** Максимальный сдвиг при параллаксе на 100% (в долях половины экрана). */
        const val MAX_PARALLAX = 0.06f

        const val VERTEX_SHADER = """
            uniform mat4 uMvp;
            uniform mat4 uTexMatrix;
            attribute vec4 aPos;
            attribute vec4 aTex;
            varying vec2 vTex;
            void main() {
                gl_Position = uMvp * aPos;
                vTex = (uTexMatrix * aTex).xy;
            }
        """

        const val FRAGMENT_SHADER = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTex;
            uniform samplerExternalOES uTex;
            uniform float uAlpha;
            void main() {
                vec4 c = texture2D(uTex, vTex);
                gl_FragColor = vec4(c.rgb * uAlpha, 1.0);
            }
        """
    }
}
