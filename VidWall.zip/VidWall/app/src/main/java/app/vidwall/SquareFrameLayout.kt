package app.vidwall

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/** Квадратная ячейка для сетки: высота равна ширине. */
class SquareFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
    }
}
