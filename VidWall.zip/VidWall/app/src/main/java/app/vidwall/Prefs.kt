package app.vidwall

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private const val KEY_LOCK_SAME = "lock_same_as_home"
    private const val KEY_SHUFFLE = "shuffle"
    private const val KEY_POWER_SAVE = "pause_power_save"
    private const val KEY_TRANSITION = "transition"
    private const val KEY_TRANSITION_MS = "transition_ms"
    private const val KEY_PARALLAX = "parallax"
    private const val KEY_TR_EASING = "transition_easing"
    private const val KEY_TR_DIR = "transition_dir"
    private const val KEY_TR_TRIGGERS = "transition_triggers"

    fun get(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences("vidwall", Context.MODE_PRIVATE)

    private fun entriesKey(profile: Profile) = "entries_${profile.key}"

    fun entries(context: Context, profile: Profile): List<VideoEntry> {
        val raw = get(context).getString(entriesKey(profile), null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                VideoEntry(
                    id = o.getLong("id"),
                    startMs = o.optLong("start", 0L),
                    endMs = o.optLong("end", 0L),
                    speed = o.optDouble("speed", 1.0).toFloat(),
                    zoom = o.optDouble("zoom", 1.0).toFloat(),
                    panX = o.optDouble("panx", 0.0).toFloat(),
                    panY = o.optDouble("pany", 0.0).toFloat()
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** JSON не принимает NaN и бесконечность: такие значения заменяем на безопасные. */
    private fun finite(v: Float, fallback: Float): Double =
        (if (v.isNaN() || v.isInfinite()) fallback else v).toDouble()

    fun setEntries(context: Context, profile: Profile, list: List<VideoEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("start", it.startMs)
                    .put("end", it.endMs)
                    .put("speed", finite(it.speed, 1f))
                    .put("zoom", finite(it.zoom, 1f))
                    .put("panx", finite(it.panX, 0f))
                    .put("pany", finite(it.panY, 0f))
            )
        }
        get(context).edit().putString(entriesKey(profile), arr.toString()).apply()
    }

    /**
     * Чей список видео реально играет на экране.
     * Рабочий стол всегда играет свой список. Экран блокировки играет свой список, только если
     * включены отдельные видео и в нём что-то выбрано; иначе (или если выбрано «те же видео»)
     * берётся список рабочего стола. Если и он пуст, играют все видео галереи.
     */
    fun sourceProfile(context: Context, profile: Profile): Profile =
        if (profile == Profile.LOCK && !lockSameAsHome(context) && entries(context, Profile.LOCK).isNotEmpty()) {
            Profile.LOCK
        } else {
            Profile.HOME
        }

    fun lockSameAsHome(context: Context) = get(context).getBoolean(KEY_LOCK_SAME, true)
    fun setLockSameAsHome(context: Context, v: Boolean) =
        get(context).edit().putBoolean(KEY_LOCK_SAME, v).apply()

    fun shuffle(context: Context) = get(context).getBoolean(KEY_SHUFFLE, false)
    fun setShuffle(context: Context, v: Boolean) =
        get(context).edit().putBoolean(KEY_SHUFFLE, v).apply()

    fun pauseOnPowerSave(context: Context) = get(context).getBoolean(KEY_POWER_SAVE, true)
    fun setPauseOnPowerSave(context: Context, v: Boolean) =
        get(context).edit().putBoolean(KEY_POWER_SAVE, v).apply()

    fun transition(context: Context) = get(context).getInt(KEY_TRANSITION, Transition.FADE)
    fun setTransition(context: Context, v: Int) =
        get(context).edit().putInt(KEY_TRANSITION, v).apply()

    /** Сила параллакса при наклоне телефона, 0 = выключено, 100 = максимум. */
    fun parallax(context: Context) = get(context).getInt(KEY_PARALLAX, 0)
    fun setParallax(context: Context, v: Int) =
        get(context).edit().putInt(KEY_PARALLAX, v).apply()

    fun transitionEasing(context: Context) = get(context).getInt(KEY_TR_EASING, Easing.SMOOTH)
    fun setTransitionEasing(context: Context, v: Int) =
        get(context).edit().putInt(KEY_TR_EASING, v).apply()

    fun transitionDir(context: Context) = get(context).getInt(KEY_TR_DIR, Dir.CENTER)
    fun setTransitionDir(context: Context, v: Int) =
        get(context).edit().putInt(KEY_TR_DIR, v).apply()

    /** Набор флагов [Trigger]. По умолчанию переход играет при включении экрана. */
    fun transitionTriggers(context: Context) = get(context).getInt(KEY_TR_TRIGGERS, Trigger.WAKE)
    fun setTransitionTriggers(context: Context, v: Int) =
        get(context).edit().putInt(KEY_TR_TRIGGERS, v).apply()

    fun transitionConfig(context: Context) = TransitionConfig(
        type = transition(context),
        durationMs = transitionMs(context).toLong(),
        easing = transitionEasing(context),
        dir = transitionDir(context)
    )

    fun transitionMs(context: Context) = get(context).getInt(KEY_TRANSITION_MS, 600)
    fun setTransitionMs(context: Context, v: Int) =
        get(context).edit().putInt(KEY_TRANSITION_MS, v).apply()
}
