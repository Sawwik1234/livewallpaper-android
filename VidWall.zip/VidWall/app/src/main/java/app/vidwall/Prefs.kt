package app.vidwall

import android.content.Context
import android.content.SharedPreferences

/** Настройки приложения. Пустой набор альбомов означает «все видео». */
object Prefs {
    private const val KEY_BUCKETS = "buckets"
    private const val KEY_SHUFFLE = "shuffle"

    fun get(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences("vidwall", Context.MODE_PRIVATE)

    fun buckets(context: Context): Set<String> =
        HashSet(get(context).getStringSet(KEY_BUCKETS, emptySet()) ?: emptySet())

    fun setBuckets(context: Context, value: Set<String>) {
        get(context).edit().putStringSet(KEY_BUCKETS, HashSet(value)).apply()
    }

    fun shuffle(context: Context): Boolean = get(context).getBoolean(KEY_SHUFFLE, false)

    fun setShuffle(context: Context, value: Boolean) {
        get(context).edit().putBoolean(KEY_SHUFFLE, value).apply()
    }
}
