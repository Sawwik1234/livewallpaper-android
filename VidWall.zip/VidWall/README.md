# VidWall

Живые обои из видео галереи (Kotlin + Media3 ExoPlayer).

Сборка: загрузите проект в репозиторий GitHub. Вкладка Actions -> Build APK -> Run workflow.
Готовый APK: Artifacts -> VidWall-apk.
